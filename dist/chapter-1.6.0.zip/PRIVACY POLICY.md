# Chapter Ghost Theme Privacy Policy

## Introduction

DevGuild Limited ("we" or "us") values its customers' privacy. This privacy policy is effective from the date of purchase; it summarizes what information we might collect from a registered user or other visitor ("you"), and what we will and will not do with it.

## What we do with your personally identifiable information

When you purchase the Chapter Ghost Theme, we collect your email address. This is used to send you a receipt and a link to download the product. We do not sell or rent your email address to third parties.

Your payment is processed by Stripe, and we do not store your payment information. Stripe may collect additional information to process your payment and combat fraud. We recommend reviewing [Stripe's Privacy Policy](https://stripe.com/privacy).

## Umbrella Policy

This Privacy Policy is specific to the Chapter Ghost Theme. For more information about how we handle personal data, please refer to the DevGuild Limited Umbrella Privacy Policy at [https://devguild.ltd/privacy-policy/](https://devguild.ltd/privacy-policy/).

## Changes to this Privacy Policy

We may change this Privacy Policy from time to time. If we make any changes, we will notify you by revising the "Effective Date" at the top of this Privacy Policy. If we make any revisions that materially change the ways in which we use or share the information previously collected from you, we will give you the opportunity to consent to such changes before applying them to that information.
