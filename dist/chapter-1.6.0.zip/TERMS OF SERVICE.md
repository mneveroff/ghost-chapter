# Terms of Service

## Acceptance of Terms

By purchasing or otherwise lawfully acquiring the Chapter theme ("the Theme"), you are agreeing to be bound by these Terms of Service. If you do not agree to these terms, do not purchase or use the Theme.

## Umbrella Terms of Service

These Terms of Service are specific to the Chapter theme. For more information about our general terms and conditions, please refer to the DevGuild Limited Umbrella Terms of Service at [https://devguild.ltd/terms-of-service/](https://devguild.ltd/terms-of-service/). In the event of any conflict between these Terms of Service and the Umbrella Terms of Service, these Terms of Service will prevail.

## Support

DevGuild Limited will provide support for the Theme for up to 1 year after your initial purchase. This support is limited to resolving issues originating from errors in the Theme itself. Support does not cover issues related to the Ghost platform, Ghost Pro, hosting issues, or other issues with client infrastructure. Support is solely for issues with the Theme and its intended functionality.

## License

Upon your purchase or other lawful acquisition of the Theme, DevGuild Limited grants you a non-exclusive, non-transferable, revocable license to use the Theme in accordance with these Terms of Service and the accompanying [License Agreement](LICENSE.md).

## Disclaimer of Warranty

The Theme is provided "as is" without warranty of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. You assume all risks associated with using the Theme.

## Limitation of Liability

In no event will DevGuild Limited or its affiliates, or any of its or their respective directors, officers, employees, or agents, be liable to you for any indirect, incidental, special, consequential, or punitive damages arising out of or relating to your use of the Theme.

## Indemnification

You agree to indemnify, defend, and hold harmless DevGuild Limited and its affiliates, and its and their respective directors, officers, employees, and agents, from and against all claims, damages, losses, and expenses of any kind arising out of or relating to your use of the Theme.

## Governing Law

These Terms of Service are governed by the laws of Scotland, United Kingdom, without regard to its conflict of laws principles.

## Changes to Terms of Service

DevGuild Limited reserves the right to modify these Terms of Service at any time. Your continued use of the Theme following any such modification constitutes your agreement to be bound by the modified Terms of Service.
